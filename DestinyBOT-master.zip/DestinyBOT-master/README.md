# Autor

DiscordTag: young#4565

YouTube: https://www.youtube.com/channel/UC4KaGNNX8hgra79SaqO02Fw?view_as=subscriber

Twitter: https://twitter.com/youngzeura

# Intuito desse GitHub

 Quero trazer esse projeto, não para deixar somente livre os códigos, esse GitHub servirá de estudo. Mas, caso queira apenas copiar, tudo bem! Espero que esse GitHub, ajude os programadores :)

# Suporte

 Caso tenha perguntas a fazer sobre esse GitHub, entre no DiscordLab, pois lá você terá um suporte muito bom!

Link: https://discord.gg/rrYhkT5

# Aviso

 Caso queira copiar meus comandos de música, saiba: Crie o arquivo **queue.js** e copie como eu fiz dentro dele. Seu comando estará pronto para ser utilizado!

```
Os comandos já possuem as dependencias instaladas, mas no caso de um erro, instale procurando dentro do arquivo!
```

