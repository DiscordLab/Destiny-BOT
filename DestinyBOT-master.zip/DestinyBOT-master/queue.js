const queue = new Map()

exports.queue = queue

exports.help = {
  name: 'queue',
  aliases: []
}
